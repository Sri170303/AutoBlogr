import logo from './logo.svg'

export const assets = {
    logo
}